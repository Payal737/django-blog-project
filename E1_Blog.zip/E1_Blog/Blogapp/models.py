from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone

class Author(models.Model):
    name = models.CharField(max_length=100)
    biography = models.TextField(blank=True,null= False )

    def __str__(self):
        return self.name


class Book(models.Model):
    class Genres(models.TextChoices):
        MYSTERY = ''
    title = models.CharField(max_length=200)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    Description = models.TextField(blank=True, null=False)
    publication_date = models.DateField(default= timezone.now)
    
    cover_image = models.ImageField(upload_to='covers/')

    def __str__(self):
        return self.title



class Review(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    reviewer_name = models.CharField(max_length=100)
    content = models.TextField()
    rating = models.PositiveIntegerField(choices=[(i, i) for i in range(1, 6)])

    def __str__(self):
        return f"Review of {self.book.title} by {self.reviewer_name}"

