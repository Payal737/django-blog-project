from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .forms import BookForm, AuthorForm
from .models import Book, Author
from django.contrib.auth.decorators import login_required


def book_create_view(request):
    form = BookForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('../homepage/')

    context = {
        'form': form
    }
    return render(request,"Blogapp/book_create_view.html", context)

def allbook(request):
    books = Book.objects.all()
    
    context = {
        'books': books
    }

    return render(request, 'Blogapp/allbooks.html', context)


def book_view(request, id):
    book = get_object_or_404(Book, id = id)
    context = {
        'book': book
    }
    return render(request, 'Blogapp/book.html', context)


def book_delete(request, id):
    post = get_object_or_404(Book, id = id)

    if request.method == 'POST':
        post.delete()
        return redirect('../../../books/')
    return render(request, 'Blogapp/delete_book.html')


def book_update(request, id):
    post = get_object_or_404(Book, id = id)

    form = BookForm(request.POST or None, instance= post)
    if form.is_valid():
        form.save()
        return redirect('../')

    context = {
        'form': form
    }
    return render(request, 'Blogapp/update_books.html', context)


def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('../homepage/')  
    else:
        form = AuthenticationForm()
    return render(request, 'Blogapp/login.html', {'form': form})

# Create your views here.
def index(request):
    return render(request, "Blogapp/index.html")
def book_blog(request):
    my_context = {
        "my_text": "this is about books",
        "number_books": 3
    }
    return render(request, "Blogapp/book_blog.html",my_context)
def landing_page(request,*args,**kwargs):
    return render(request,"Blogapp/landing_page.html",{})
def homepage(request):
    return render(request, "Blogapp/homepage.html")

def signup(request):
    if request.method == 'POST':
        # If the request method is POST, it means the user submitted the registration form.
        form = UserCreationForm(request.POST)
        if form.is_valid():
            # If the form data is valid, create a new user account.
            user = form.save()
            # Log in the user immediately after registration.
            login(request, user)
            # Redirect to a success page or dashboard.
            return redirect('../login/')  # You should define 'dashboard' in your URL patterns.

    else:
        # If the request method is GET, display the registration form.
        form = UserCreationForm()

    return render(request, 'Blogapp/signup.html', {'form': form})
def Genres(request):
    return render(request, 'Blogapp/Genres.html')
def Mystery(request):
    return render(request, 'Blogapp/Mystery.html')

@login_required(login_url= '../login/') 
def user_logout(request): 
    if request.method == "POST": 
        logout(request) 
        return redirect('../homepage/') 
    return render(request, 'Blogapp/logout.html', {})

from django.shortcuts import render
from E1_Blog.settings import EMAIL_HOST_USER
from . import forms
from django.core.mail import send_mail

# Create your views here.
#DataFlair #Send Email
def feedback(request):
    sub = forms.Feedback()
    if request.method == 'POST':
        sub = forms.Feedback(request.POST)
        subject = 'Welcome to Rucler Technologies'
        message = 'Good Efforts and Hope you are enjoying your Work'
        recepient = str(sub['Email'].value())
        send_mail(subject, 
            message, EMAIL_HOST_USER, [recepient], fail_silently = False)
        return render(request, 'Blogapp/success.html', {'recepient': recepient})
    return render(request, 'Blogapp/indx.html', {'form':sub})


def author_view(request):
    authors = Author.objects.all()

    context = {
        'authors': authors
    }

    return render(request, 'Blogapp/Authors.html', context)


def author_detail(request, id):
    author = get_object_or_404(Author, id = id)

    context = {
        'author': author
    }

    return render(request, 'Blogapp/author.html', context)